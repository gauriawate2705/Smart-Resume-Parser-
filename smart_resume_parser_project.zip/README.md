# Smart Resume Parser

## Overview
A simple project that extracts text from resumes (PDF/DOCX), parses key sections using spaCy + regex, and exports structured results.

## Features
- PDF/DOCX text extraction
- Skills, Experience, Education parsing
- JSON export
- Command-line interface

## How to Run
```
pip install -r requirements.txt
python main.py sample_resume.pdf
```
