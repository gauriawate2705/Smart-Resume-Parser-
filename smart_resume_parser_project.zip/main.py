import fitz
import docx
import re
import json
import sys

def extract_text(file_path):
    if file_path.endswith('.pdf'):
        doc = fitz.open(file_path)
        return "\n".join([page.get_text() for page in doc])
    elif file_path.endswith('.docx'):
        doc = docx.Document(file_path)
        return "\n".join([p.text for p in doc.paragraphs])
    else:
        raise ValueError("Unsupported file format")

def parse_sections(text):
    sections = {
        "skills": re.findall(r"Skills?:\s*(.*)", text, re.I),
        "experience": re.findall(r"Experience:?(.+?)(?:Education|$)", text, re.I | re.S),
        "education": re.findall(r"Education:?(.+?)(?:Skills|Experience|$)", text, re.I | re.S)
    }
    return sections

def main():
    if len(sys.argv) < 2:
        print("Usage: python main.py <resume>")
        return
    file_path = sys.argv[1]
    text = extract_text(file_path)
    parsed = parse_sections(text)
    with open("output.json", "w") as f:
        json.dump(parsed, f, indent=4)
    print("Parsed output saved to output.json")

if __name__ == "__main__":
    main()
